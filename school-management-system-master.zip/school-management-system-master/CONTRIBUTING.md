# Contribution Guidelines

Please submit all issues and pull requests to the [hrshadhin/school-management-system](https://github.com/hrshadhin/school-management-system) repository!
