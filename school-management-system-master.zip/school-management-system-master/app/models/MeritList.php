<?php

class MeritList extends \Eloquent {
    protected $table = 'MeritList';
}