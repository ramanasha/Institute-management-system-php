<?php

class ClassModel extends \Eloquent {
	 protected $table = 'Class';
	protected $fillable = ['name','code','description','combinePass'];

}
