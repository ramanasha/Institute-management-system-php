  <!-- footer content -->
  <footer class="footer">
         <hr>
        <p class="col-md-3 col-sm-3 col-xs-12 copyright"> <a href="#" target="_blank">{{Session::get('inName')}}</a> &copy;{{date('Y')}}</p>
        <p class="col-md-9 col-sm-9 col-xs-12 powered-by">
         <!-- Don't remove below text. Its againts copy right laws. -->
         <strong>School Management System Version 1.0 - {{substr($idc,0,7)}}</strong> || Developed by <a class="cplink" href="http://shanixlab.com">ShanixLab</a>
        </p> 
  </footer>
  <!-- /footer content -->
</div>
</div>